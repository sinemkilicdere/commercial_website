CREATE TABLE Tours (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    tourName VARCHAR(100) NOT NULL,
    description VARCHAR(255) NOT NULL,
    price VARCHAR(50) NOT NULL,
    ticketsLeft VARCHAR(50) NOT NULL, 
    image VARCHAR(50) NOT NULL
);

INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('$tourName', 'Explore the iconic landmarks of NYC with our experienced guides.', '100', '50', '')

INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('Highlights', 'Explore the iconic landmarks of NYC with our experienced guides.', '100', '50', 'highlights.jpg')


INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('Central Park', 'Explore the iconic landmarks of Central Park with our experienced guides.', '25', '2', 'centralpark.jpg')


INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('Helicopter', 'Explore the iconic landmarks of NYC with our experienced Helicopters.', '400', '50', 'helicopter.jpg')


INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('Island Cruise', 'Explore the iconic landmarks of NYC with our experienced Cruise.', '300', '50', 'cruise.jpg')


INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('Food Tour', 'Explore the iconic restaurants of NYC with our experienced guides.', '100', '50', 'food.jpg')


INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('Bridge', 'Explore the iconic landmarks of bridges with our experienced guides.', '100', '50', 'bridges.jpg');

INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('Swimming Pool', 'Explore the iconic landmarks of bridges with our experienced guides.', '100', '50', 'bridges.jpg');

INSERT INTO Tours (tourName, description, price, ticketsLeft, image)
VALUES ('Sandwich', 'Explore the iconic landmarks of bridges with our experienced guides.', '100', '50', 'bridges.jpg');



CREATE TABLE IF NOT EXISTS Card (
            id INT NOT NULL AUTO_INCREMENT, 
            fullname VARCHAR(30) NOT NULL,
            cardNumber VARCHAR(30) NOT NULL PRIMARY KEY,
            expirationDate VARCHAR(255) NOT NULL,
            cvv VARCHAR(50) NOT NULL,
            paymentMethod VARCHAR(30) NOT NULL,
            userID INT NOT NULL,
            FOREIGN KEY (userID) REFERENCES TicketUsers(id)
)


CREATE TABLE IF NOT EXISTS UserTour (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    tourID INT,
    userID INT,
    FOREIGN KEY (tourID) REFERENCES Tours(id),
    FOREIGN KEY (userID) REFERENCES TicketUsers(id)
);

CREATE TABLE IF NOT EXISTS Trips (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
            people VARCHAR(30) NOT NULL,
            pickup VARCHAR(255) NOT NULL,
            insurance VARCHAR(50) NOT NULL,
            day VARCHAR(30) NOT NULL,
            timeframe VARCHAR(255) NOT NULL,
            userID INT NOT NULL,
            FOREIGN KEY (userID) REFERENCES TicketUsers(id)
        )


UPDATE table_name
SET column_name = new_value
WHERE condition;