<?php
$request = $_SERVER['REQUEST_URI'];

// Remove query string for cleaner matching
$request = strtok($request, '?');


if ($request === '/mac272/FinalProject/red_hawk/' || $request === '/mac272/FinalProject/red_hawk') {
    header("Location: /mac272/FinalProject/red_hawk/content/red_hawk.php");
    exit();
}

// Define the path to your content directory
$content_dir = __DIR__ . '/content';

// Construct the file path
$file = $content_dir . $request . '.php';

if (file_exists($file)) {
    include $file;
} else {
    // Send 404 header
    header("HTTP/1.0 404 Not Found");
    // Include the 404 page
    include __DIR__ . '/404.html';
}
