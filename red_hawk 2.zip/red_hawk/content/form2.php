<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book NYC Highlights Tour - Red Hawk Trip Planner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        header {
            background-color: #000;
            color: #fff;
            padding: 0px 0;
            text-align: center;
        }

        .tour-details {
            display: flex;
            justify-content: space-around;
            align-items: flex-start;
            text-align: left;
            padding: 50px 20px;
            box-sizing: border-box;
        }

        .tour-details h1 {
            color: #FF0000;
        }

        .tour-details img {
            width: 100%;
            max-width: 400px;
            height: auto;
            margin-bottom: 20px;
        }

        .tour-highlights {
            width: 45%;
            margin-left: 10em;
        }

        .tour-highlights h2 {
            color: #000;
        }

        .tour-highlights ul {
            list-style: none;
            padding: 0;
        }

        .tour-highlights li {
            margin-bottom: 10px;
        }

        .booking-form {
            max-width: 600px;
            margin-right: 10em;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            box-sizing: border-box;
        }

        .booking-form label {
            display: block;
            margin-bottom: 10px;
            color: #000;
        }

        .booking-form input,
        .booking-form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .booking-form button {
            background-color: #FF0000;
            color: #fff;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            display: block;
            margin: 0 auto;
        }

        footer {
            background-color: #000;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        footer a {
            color: #FF0000;
            text-decoration: none;
        }
    </style>
</head>

<body>
<?php 
    $fullname = $email = $phone = $address = $people = $pickup = $insurance = $day = $timeframe = $location = $userID  = "";

    if(isset($_POST['submit'])) {
        $fullname = $_POST['fullname'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $people = $_POST['people'];
        $pickup = $_POST['pickup'];
        $insurance = $_POST['insurance'];
        $day = $_POST['day'];
        $timeframe = $_POST['timeframe'];
        $location = $_POST['location'];
        $userID = 1; // Assuming userID is 1 for demonstration purposes

        $host = "localhost";
        $user = "root";
        $password = ""; // Corrected variable name
        $database = "test";
        $connect = mysqli_connect($host, $user, $password, $database);

        if(mysqli_connect_errno()){
            die("Cannot connect to database field: " . mysqli_connect_error());
        } else {
            echo 'Database is connected';  
        }

        $sql = "CREATE TABLE IF NOT EXISTS CentralPark (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
            fullname VARCHAR(30) NOT NULL,
            email VARCHAR(30) NOT NULL,
            phone VARCHAR(255) NOT NULL,
            address VARCHAR(50) NOT NULL,
            people VARCHAR(30) NOT NULL,
            pickup VARCHAR(255) NOT NULL,
            insurance VARCHAR(50) NOT NULL,
            day VARCHAR(30) NOT NULL,
            timeframe VARCHAR(255) NOT NULL,
            location VARCHAR(50) NOT NULL,
            userID INT NOT NULL,
            FOREIGN KEY (userID) REFERENCES usersfinal(id)
        )";

        if(mysqli_query($connect, $sql)) {
            echo "Table Highlights created successfully";
        } else {
            echo "Error creating table: " . mysqli_error($connect);  
        }

        $sql = "INSERT INTO CentralPark (fullname, email, phone, address, people, pickup, insurance, day, timeframe, location, userID) 
                VALUES ('$fullname', '$email', '$phone', '$address', '$people', '$pickup', '$insurance', '$day', '$timeframe', '$location', '$userID')";

        if (mysqli_query($connect, $sql)) {
            echo "New records created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }

        header("Location: ccard.php");

        mysqli_close($connect);
    }
?>

    <header>
        <img src="./assets/RED HAWK.png" alt="Red Hawk Trip Planner Logo">
    </header>

    

    <div class="tour-details">
        <div class="tour-highlights">
            <h2>Time Frames</h2>
            <ul>
                <li>Morning: 9:00 AM - 12:00 PM</li>
                <li>Afternoon: 1:00 PM - 4:00 PM</li>
                <li>Evening: 5:00 PM - 8:00 PM</li>
            </ul>

              <h2>Central Park Adventures</h2>
            <ul>
                <li>Morning Adventure (9:00 AM - 12:00 PM):</li>
                <ul>
                    <li>Explore Bethesda Terrace and Fountain</li>
                    <li>Boat ride on The Lake</li>
                    <li>Visit The Central Park Zoo</li>
                </ul>
                <li>Afternoon Adventure (1:00 PM - 4:00 PM):</li>
                <ul>
                    <li>Picnic at Sheep Meadow</li>
                    <li>Walk through The Ramble</li>
                    <li>Visit The Metropolitan Museum of Art (nearby)</li>
                </ul>
                <li>Evening Adventure (5:00 PM - 8:00 PM):</li>
                <ul>
                    <li>Enjoy a carriage ride around The Great Lawn</li>
                    <li>Watch a performance at Delacorte Theater (seasonal)</li>
                    <li>Dinner at Tavern on the Green</li>
                </ul>
            </ul>
        </div>

        <div class="booking-form">
            <h2>Submit and Make a Payment</h2>
            <form action="" method="post">
                <label for="fullname">Full Name:</label>
                <input type="text" id="fullname" name="fullname" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" required>

                <label for="address">Address:</label>
                <input type="text" id="address" name="address" required>

                <label for="people">Number of People:</label>
                <input type="number" id="people" name="people" required>

                <label for="pickup">Pick-up Location:</label>
                <select id="pickup" name="pickup" required>
                    <option value="times_square">Times Square</option>
                    <option value="central_park">Central Park</option>
                    <option value="empire_state">Empire State Building</option>
                </select>

                <label for="insurance">Insurance:</label>
                <select id="insurance" name="insurance" required>
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                </select>

                <label for="day">Preferred Day (Select from Calendar):</label>
                <input type="date" id="day" name="day" required>

                <label for="timeframe">Preferred Time Frame:</label>
                <select id="timeframe" name="timeframe" required>
                    <option value="morning">Morning (10:00 AM - 1:00 PM)</option>
                    <option value="afternoon">Afternoon (2:00 PM - 5:00 PM)</option>
                    <option value="evening">Evening (6:00 PM - 9:00 PM)</option>
                </select>

                <label for="location">Preferred Location:</label>
                <select id="location" name="location" required>
                    <option value="times_square_location">Times Square Location</option>
                    <option value="central_park_location">Central Park Location</option>
                    <option value="empire_state_location">Empire State Building Location</option>
                </select>

                <p>Note: The remaining payment will be charged at the pick-up location.Minimum deposit amount $50 per person.</p>

                <input type="submit" name="submit" value="Submit and Make a Payment" class="btn-green">

            </form>
        </div>
    </div>

    <footer>
        <p>Contact Information: <a href="mailto:info@travelixtripplanner.com">info@travelix.com</a></p>
        <p>Follow Us: <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a></p>
        <p>&copy; 2023 Travelix Trip Planner. All rights reserved.</p>
        <p><a href="aboutUs.html">About Us</a></p>
    </footer>
</body>

</html>
