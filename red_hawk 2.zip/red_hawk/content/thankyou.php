<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { 
            display : flex; 
            flex-direction : column;
            align-items : center;
            justify-content : center;
            font-size : 5em;
        }
    </style>
</head>
<body>
    <h4>Thank you for filling out the form.</h4>
    <br/>
    <a href='./red_hawk.php'>Go Home</a>

</body>
</html>