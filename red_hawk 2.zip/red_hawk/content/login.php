<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .search-button {
    background-color: #FF0000;
    color: #fff;
    border: none;
    padding: 15px 30px;
    font-size: 18px;
    cursor: pointer;
    border-radius: 5px;
    width:10em;
}

    </style>
</head>

<body>

 <?php

if(isset($_POST['submit'])) {
    $incorrectLogin = false;
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $userPassword = $_POST['userPassword'];

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "test";
   
    $conn = mysqli_connect($host, $user, $password, $database);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
   
    $sql = "SELECT id, name, username, userpassword, email FROM TicketUsers";
    $result = mysqli_query($conn, $sql);
   
    // Check if query executed successfully
    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }
   
    // Check if there are any rows returned
    if (mysqli_num_rows($result) > 0) {
        // Output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
            
            if($username == "admin"){
                header("Location: adminPortal.php");
            } else if($row["username"] == $username && $row["userPassword"] == $password) {
                session_start();
                $_SESSION['Name'] = $username;
                $_SESSION['UserID'] = $row['id'];
                header("Location: red_hawk.php");
            }else {
                $incorrectLogin = true;
            }
        }
    } else {
        $incorrectLogin = true;
        echo "0 results";
    }
   
    mysqli_close($conn);

}

 ?>
  <header>
        <img src="../assets/RED HAWK.png" alt="Red Hawk Trip Planner Logo">
    </header>
<section class="section-form">
<form action="" method="post" class="login-form"  >
        <h3>Form Login</h3>
        <input type="text" name="username" placeholder="Username">
        <br>
        <input type="password" name="userPassword" placeholder="Password">
        <br>
        <?php
if ($incorrectLogin) {
    echo "<p style='color: red;'>Username or password incorrect.</p>";
}
?>
        <div class="form-container">
        <input type="submit" name="submit" value="Login" class="search-button">
        <a href="./register.php" class="btn-black">Create an Account?</a>
        </div>
       

    </form>
</section>
 


</body>
</html>