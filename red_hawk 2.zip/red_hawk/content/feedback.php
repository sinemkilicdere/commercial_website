<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="feedbackStyles.css">
    <link rel="stylesheet" href="styles.css">
</head>
    <style>
           .feedback-button {
            background-color: #FF0000;
            color: #fff;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
        }

    </style>
<body>


<?php


    $userID = $q1 = $q2 = $q3 = $q4 = "";

    if(isset($_POST['submit'])) {
        $userID = $_POST['userID'];
        $q1 = $_POST['q1'];
        $q2 = $_POST['q2'];
        $q3 = $_POST['q3'];
        $q4 = $_POST['q4'];

        $host = "localhost";
        $user = "root";
        $password = ""; // Corrected variable name
        $database = "test";
        $connect = mysqli_connect($host, $user, $password, $database);

        if(mysqli_connect_errno()){
            die("Cannot connect to database field: " . mysqli_connect_error());
        } else {
            echo 'Database is connected';  
        }

        $sql = "CREATE TABLE IF NOT EXISTS Feedback (
            feedbackID INT AUTO_INCREMENT PRIMARY KEY, 
            userID INT NOT NULL,
            feedbackDate DATETIME DEFAULT CURRENT_TIMESTAMP, 
            q1 VARCHAR(30) NOT NULL,
            q2 VARCHAR(30) NOT NULL,
            q3 VARCHAR(255) NOT NULL,
            q4 VARCHAR(50),
            FOREIGN KEY (userID) REFERENCES TicketUsers(id)
        )";

        if(mysqli_query($connect, $sql)) {
            echo "Table User created successfully";
        } else {
            echo "Error creating table: " . mysqli_error($connect);  
        }

        $sql = "INSERT INTO Feedback (userID, q1, q2, q3, q4) VALUES ('$userID' ,'$q1', '$q2', '$q3' , '$q4')";

        if (mysqli_query($connect, $sql)) {
            echo "New records created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }

        header("Location: thankyou.php");

        mysqli_close($connect);
    }
?>

<h3>Help us improve</h3>
<form action="" method="post">
    <label>Enter Your User ID Number?</label>
    <input type="text" name="userID" class="userID">
    <br>
    <label>How often do you use our app?</label>
    <textarea name="q1" id="" cols="60" rows="8"></textarea>
    <br>
    <label>What is the motivation to use our app?</label>
    <textarea name="q2" id="" cols="60" rows="8"></textarea>
    <br>
    <label>What is your most used feature?</label>
    <textarea name="q3" id="" cols="60" rows="8"></textarea>
    <br>
    <label>What would you like to see improved the most?</label>
    <textarea name="q4" id="" cols="60" rows="8"></textarea>
    <br>
    <input type="submit" name="submit" value="submit" class="feedback-button">
</form>

<hr>

</body>
</html>
