<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Red Hawk Trip Planner</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        header {
            background-color: #000;
            color: #fff;
            padding: 0px 0;
            text-align: center;
        }

        nav {
            background-color: #FF0000;
            text-align: center;
            padding: 10px 0;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 20px;
            font-weight: bold;
        }

        .main-banner {
            background: url('OIP.jpg') no-repeat center center/cover;
            color: #fff;
            text-align: center;
            padding: 100px 0;
        }

        .options {
            display: flex;
            justify-content: space-around;
            padding: 50px 0;
            flex-wrap: wrap;
        }

        .option {
            width: 300px;
            text-align: center;
            margin: 20px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .option img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            margin-bottom: 20px;
        }

        .calendar {
            text-align: center;
            padding: 50px 0;
        }

        /* .search-button {
            background-color: #FF0000;
            color: #fff;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
        } */

        footer {
            background-color: #000;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        footer a {
            color: #FF0000;
            text-decoration: none;

        }

        .tour-options {
            display : flex;

        }

        .tour-section h1,
        .tour-option h2,
        .tour-option p {
            color: #000; }
 .tour-option img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            margin-bottom: 20px;
        }

        /* Add this if you want to ensure the circular images are centered */
        .tour-option {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 1em;
        }
    </style>
    
</head>

<body>

<?php


// Check if the "Book Now" button is clicked
if(isset($_POST['book_button'])) {
    session_start();
    // Get the tour ID from the form
    $tour_id = $_POST['tour_id'];

    // Store the tour ID in a session variable
    $_SESSION['tour_id'] = $tour_id;

    // Redirect to the booking form page
    header("Location: form.php");
    exit();
}



// Database connection parameters
$host = "localhost";
$user = "root";
$password = "";
$database = "test";

// Connect to the database
$connect = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}


?>
    <header>
        <img src="../assets/RED HAWK.png" alt="Red Hawk Trip Planner Logo">
    </header>
    <nav>
        <a href="./red_hawk.php">Home</a>
        <a href="./nyc_trip.html">Guided Daily NYC Trips</a>
        <a href="./car_rentals.html">Car Rentals</a>
        <a href="./entrance_tickets.html">Sight Tickets</a>
        <a href="./bus_ticket.html">MTA/Bus Tickets</a>
    </nav>

    <div class="main-banner">



  <div class="tour-section">
            <h1>Explore NYC with Our Guided Tours</h1>
            <div class="tour-options">

<?php
            // SQL query to select all data from the Tours table
$sql = "SELECT * FROM Tours";

// Execute the query
$result = mysqli_query($connect, $sql);

// Check if any rows were returned
if (mysqli_num_rows($result) > 0) {
    // Output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        // Output the tour details
        echo "<div class='tour-option'>";
        echo "<img src='../assets/{$row['image']}' alt='{$row['image']}'>";
        echo "<h2>{$row['tourName']}</h2>";
        echo "<p>{$row['description']}</p>";
        echo "<p>Price: $ {$row['price']}</p>";
        echo "<p>Tickets Left: {$row['ticketsLeft']}</p>";

        echo "<form action='' method='post'>";
        echo "<input type='hidden' name='tour_id' value='" . $row['id'] . "'>";
        echo '<button type="submit" name="book_button" class="book-button">Book Now</button>';
        echo '</form>';
        echo "</div>";
    }
} else {
    echo "0 results";
}

// Close the database connection
mysqli_close($connect);
?>


               
        </div>
    </div>

    <!-- Add your footer here -->

    <script>
        // JavaScript to handle tour booking button click
        const bookButtons = document.querySelectorAll('.book-button');
        bookButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tourName = button.getAttribute('data-tour');
                // Redirect to the booking page or handle booking logic here
                // You can send tourName to your backend for processing
                // Example: window.location.href = `/book-tour?tour=${tourName}`;
            });
        });
    </script>

    <footer>
        <p>Contact Information: <a href="mailto:info@travelixtripplanner.com">info@travelix.com</a></p>
        <p>Follow Us: <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a></p>
        <p>&copy; 2023 Travelix Trip Planner. All rights reserved.</p>
    <!-- Other footer content -->
    <p><a href="aboutUs.html">About Us</a></p>
    </footer>
</body>

</html>
