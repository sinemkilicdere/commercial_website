<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .search-button {
            background-color: #FF0000;
            color: #fff;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            width: 10em;
        }
    </style>
</head>
<body>

<?php 
$name = $username = $email = $userPassword = "";

$isNameError = FALSE;
$isUsernameError = FALSE;
$isEmailError = FALSE;
$isUserPasswordError = FALSE;

if (isset($_POST['submit'])) {

    $isNameError = FALSE;
    $isUsernameError = FALSE;
    $isEmailError = FALSE;
    $isUserPasswordError = FALSE;

    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $userPassword = $_POST['userpassword']; 

    $nameErr = $usernameErr = $emailErr = $userPasswordErr = "";

    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
        $isNameError = TRUE;
    } else {
        if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
            $nameErr = "Only letters and white space allowed";
            $isNameError = TRUE;
        }
    }

    if (empty($_POST["username"])) {
        $usernameErr = "Username is required";
        $isUsernameError = TRUE;
    } else {
        $username = test_input($_POST["username"]);
        if (!preg_match("/^[a-zA-Z0-9-' ]*$/", $username)) {
            $usernameErr = "Only letters, numbers and white space allowed";
            $isUsernameError = TRUE;
        }
    }

    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
        $isEmailError = TRUE;
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
            $isEmailError = TRUE;
        }
    }

    if (!$isEmailError && !$isNameError && !$isUsernameError && !$isUserPasswordError) {
        $userPassword = md5($_POST['userpassword']); // Ensure this matches the form field name

        $host = "localhost";
        $user = "root";
        $password = ""; 
        $database = "test";
        $connect = mysqli_connect($host, $user, $password, $database);

        if (mysqli_connect_errno()) {
            die("Cannot connect to database: " . mysqli_connect_error());
        } else {
            session_start();
            $_SESSION['Name'] = $username;

            // Create table if it doesn't exist
            $sql = "CREATE TABLE IF NOT EXISTS TicketUsers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(30) NOT NULL,
                username VARCHAR(30) NOT NULL,
                userPassword VARCHAR(255) NOT NULL,
                email VARCHAR(50) NOT NULL
            )";

            if (!mysqli_query($connect, $sql)) {
                echo "Error creating table: " . mysqli_error($connect);  
            }

            // Use prepared statement to insert data
            $stmt = $connect->prepare("INSERT INTO TicketUsers (name, username, userPassword, email) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $username, $userPassword, $email);

            if ($stmt->execute()) {
                echo "New records created successfully";
                header("Location: red_hawk.php");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
            mysqli_close($connect);
        }
    }
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    return $data;
}      
?>

<header>
    <img src="../assets/RED HAWK.png" alt="Red Hawk Trip Planner Logo">
</header>

<section class="section-form">
<form action="" method="post" class="login-form">
    <h3>Form Registration</h3>
    <label for="Name">Name</label>
    <input placeholder="Name" required type="text" name="name" value="<?php echo htmlspecialchars($name); ?>">
    <span class="error"><?php echo $nameErr; ?></span>
    <br>
    <label for="username">Username</label>
    <input required type="text" placeholder="Username" name="username" value="<?php echo htmlspecialchars($username); ?>">
    <span class="error"><?php echo $usernameErr; ?></span>
    <br>
    <label for="email">Email</label>
    <input required type="text" placeholder="Email" name="email" value="<?php echo htmlspecialchars($email); ?>">
    <span class="error"><?php echo $emailErr; ?></span>
    <br>
    <label for="password">Password</label>
    <input required type="password" placeholder="Password" name="userpassword" value="<?php echo htmlspecialchars($userPassword); ?>">
    <span class="error"><?php echo $userPasswordErr; ?></span>
    <br>
    <div class="form-container">
        <input type="submit" name="submit" value="Register" class="search-button">
        <a href="./login.php" class="btn-black">Login?</a>
    </div>
</form>
</section>

</body>
</html>
