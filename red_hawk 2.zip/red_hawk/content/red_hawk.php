<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Red Hawk Trip Planner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        header {
            background-color: #000;
            color: #fff;
            padding: 0px 0;
            text-align: center;
            position: relative;
        }

        nav {
            background-color: #FF0000;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px 20px;
            position: relative;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 20px;
            font-weight: bold;
        }

        .nav-links {
            display: flex;
        }

        .login-button, .user-name {
            position: absolute;
            right: 20px;
            bottom : 2px;
        }

        .login-button button {
            background-color: #fff;
            color: #FF0000;
            border: none;
            padding: 10px 20px;
            font-weight: bold;
            cursor: pointer;
            border-radius: 5px;
        }

        .main-banner {
            background: url('../assets/new york background.jpg') no-repeat center center/cover;
            color: white;
            text-align: center;
            padding: 100px 0;
        }

        .options {
            display: flex;
            justify-content: space-around;
            padding: 50px 0;
            flex-wrap: wrap;
        }

        .option {
            width: 300px;
            text-align: center;
            margin: 20px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .option img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            margin-bottom: 20px;
        }

        .calendar {
            text-align: center;
            padding: 50px 0;
        }

        .search-button {
            background-color: #FF0000;
            color: #fff;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
        }

        footer {
            background-color: #000;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        footer a {
            color: #FF0000;
            text-decoration: none;
        }

        .feedback-button {
            background-color: #fff;
            color: #FF0000;
            border: none;
            padding: 10px 20px;
            font-weight: bold;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <?php 
        session_start();
    ?>
    <header>
        <img src="../assets/RED HAWK.png" alt="Red Hawk Trip Planner Logo">
    </header>
    <nav>
        <div class="nav-links">
            <a href="./red_hawk.php">Home</a>
            <a href="./nyc_trip.php">Guided Daily NYC Trips</a>
            <a href="./car_rentals.html">Car Rentals</a>
            <a href="./entrance_tickets.html">Sight Tickets</a>
            <a href="./bus_ticket.html">MTA/Bus Tickets</a>
        </div>
        <div class="user-name">
            <?php
                if (isset($_SESSION["Name"])) {
                    echo  "<a>" . "Welcome, " . htmlspecialchars($_SESSION["Name"]) . "</a>" ;
                    echo "<a href='logout.php'><button class='feedback-button'>Logout</button></a>";
                } else {
                    echo '<a href="./login.php">Login</a>';
                }
            ?>
        </div>
    </nav>

    <div class="main-banner">
        <h1>Explore New York City with Travelix Trip Planner</h1>
        <p>Your Perfect Travel Companion</p>
    </div>
    <div class="options">
        <div class="option">
            <img src="../assets/new-york.jpg" alt="Daily NYC Trips Icon">
            <h2>Guided Daily NYC Trips</h2>
            <p>Explore our guided tours and itineraries for a memorable experience in New York City.</p>
            <button>View Trips</button>
        </div>
        <div class="option">
            <img src="../assets/car rental.jpg" alt="Car Rentals Icon">
            <h2>Car Rentals</h2>
            <p>Rent a reliable vehicle for your journey, with options ranging from luxury cars to budget-friendly choices.</p>
            <button>View Cars</button>
        </div>
        <div class="option">
            <img src="../assets/museum ticket.jpg" alt="Entrance Tickets Icon">
            <h2>Sights Tickets</h2>
            <p>Get tickets to popular attractions, museums, and events, skip the lines, and enjoy seamless entry.</p>
            <button>View Tickets</button>
        </div>
        <div class="option">
            <img src="../assets/bus ticket.jpg" alt="Bus Tickets Icon">
            <h2>MTA/Bus Tickets</h2>
            <p>Book comfortable and convenient bus tickets for your travel needs, ensuring a hassle-free journey.</p>
            <button>View Bus Routes</button>
        </div>
    </div>
    <div class="calendar">
        <h2>Select Your Preferred Date</h2>
        <input type="date">
        <button class="search-button">Search</button>
        <br>
        <br>
        <br>
        <a class="feedback-button" href="./feedback.php">Feedback</a>
    </div>

    <footer>
        <p>Contact Information: <a href="mailto:info@travelixtripplanner.com">info@travelix.com</a></p>
        <p>Follow Us: <a href="https://www.facebook.com/">Facebook</a> | <a href="https://twitter.com/">Twitter</a> | <a href="https://www.instagram.com/">Instagram</a></p>
        <p>&copy; 2023 Travelix Trip Planner. All rights reserved.</p>
        <p><a href="aboutUs.html">About Us</a></p>
    </footer>
</body>

</html>
