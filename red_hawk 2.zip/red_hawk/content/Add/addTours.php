<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Tour</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <img src="../../assets/RED HAWK.png" alt="Red Hawk Trip Planner Logo">
    </header>

    <h2>Add New Tour</h2>
    <form action="addTours.php" method="post">
        <label for="tourName">Tour Name:</label>
        <input type="text" id="tourName" name="tourName" required><br><br>
        <label for="description">Description:</label>
        <input type="text" id="description" name="description" required><br><br>
        <label for="price">Price:</label>
        <input type="number" id="price" name="price" required><br><br>
        <label for="ticketsLeft">Tickets Left:</label>
        <input type="number" id="ticketsLeft" name="ticketsLeft" required><br><br>
        <label for="image">Image URL:</label>
        <input type="text" id="image" name="image" required><br><br>
        <input type="submit" value="Add Tour">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection parameters
        $host = "localhost";
        $user = "root";
        $password = "";
        $database = "test";

        // Establish a connection to the database
        $conn = mysqli_connect($host, $user, $password, $database);
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Retrieve form data
        $tourName = mysqli_real_escape_string($conn, $_POST["tourName"]);
        $description = mysqli_real_escape_string($conn, $_POST["description"]);
        $price = mysqli_real_escape_string($conn, $_POST["price"]);
        $ticketsLeft = mysqli_real_escape_string($conn, $_POST["ticketsLeft"]);
        $image = mysqli_real_escape_string($conn, $_POST["image"]);

        // Query to insert new tour information
        $sql = "INSERT INTO Tours (tourName, description, price, ticketsLeft, image) VALUES ('$tourName', '$description', '$price', '$ticketsLeft', '$image')";
        if (mysqli_query($conn, $sql)) {
            header("Location: ../adminPortal.php");
        } else {
            echo "Error adding tour: " . mysqli_error($conn);
        }

        // Close the database connection
        mysqli_close($conn);
    }
    ?>
</body>
</html>
