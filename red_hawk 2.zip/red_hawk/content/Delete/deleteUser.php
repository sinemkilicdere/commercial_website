<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username'])) {
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "test";

    $conn = mysqli_connect($host, $user, $password, $database);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $username = $_POST['username'];
    $sql = "DELETE FROM TicketUsers WHERE username = '$username'";
    if (mysqli_query($conn, $sql)) {
        echo "User deleted successfully.";
        header("Location: ../adminPortal.php");
        exit();
    } else {
        echo "Error deleting user: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Invalid request.";
}
?>