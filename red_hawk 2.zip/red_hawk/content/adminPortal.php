<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <img src="../assets/RED HAWK.png" alt="Red Hawk Trip Planner Logo">
    </header>
    <link rel="stylesheet" href="admin.css">

    <?php
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "test";

    $conn = mysqli_connect($host, $user, $password, $database);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM TicketUsers";
    $result = mysqli_query($conn, $sql);

    // Check if query executed successfully
    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    // Check if there are any rows returned
    if (mysqli_num_rows($result) > 0) {
        // Output data of each row

        echo "<table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Username</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>" . $row['username'] . "</td>";
            echo "<td>" . $row['email'] . "</td>";
            echo "<td>";
            echo "<form action='./Delete/deleteUser.php' method='post'>";
            echo "<input type='hidden' name='username' value='" . $row['username'] . "'>";
            echo "<button type='submit' class='deleteBtn'>Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
            echo "<br>";
        }

        echo "</tbody>
        </table>";
    } else {
        echo "0 results";
    }

    $sql = "SELECT * FROM Tours";
    $result = mysqli_query($conn, $sql);

    // Check if query executed successfully
    if (!$result) {
        die("Query failed: " . mysqli_error($conn));
    }

    // Check if there are any rows returned
    if (mysqli_num_rows($result) > 0) {
        // Output data of each row
       
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";

        echo "<form action='./Add/addTours.php'>";
        echo "<button type='submit' class='editBtn'>Add</button>";
        echo "<input type='hidden' name='username' value='" . $row['id'] . "'>";
        echo "</form>";

        echo "<table>
        <thead>
            <tr>
                <th>Tour ID</th>
                <th>Tour Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Ticket Left</th>
                <th>Image URL</th>
            </tr>
        </thead>
        <tbody>
        ";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['tourName'] . "</td>";
            echo "<td>" . $row['description'] . "</td>";
            echo "<td>" . $row['price'] . "</td>";
            echo "<td>" . $row['ticketsLeft'] . "</td>";
            echo "<td>" . $row['image'] . "</td>";
            echo "<td>";
         
            echo "<form action='./Edit/editTours.php' method='post'>";
            echo "<button type='submit' class='editBtn'>Edit</button>";
            echo "<input type='hidden' name='tourName' value='" . $row['tourName'] . "'>";
            echo "</form>";
            echo "<form action='./Delete/deleteTours.php' method='post'>";
            echo "<input type='hidden' name='tourName' value='" . $row['tourName'] . "'>";
            echo "<button type='submit' class='deleteBtn'>Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
            echo "<br>";
        }

        echo "</tbody>
        </table>";
    } else {
        echo "0 results";
    }

    mysqli_close($conn);
    ?>

</body>
</html>