<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Red Hawk Trip Planner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        header {
            background-color: #000;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        .payment-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 30px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            box-sizing: border-box;
        }

        .payment-container h2 {
            color: #FF0000;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #000;
        }

        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .payment-info {
            display: none;
        }

        #payment-method {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .payment-info {
            display: none;
            margin-top: 10px;
        }

        #paypal-info,
        #apple-pay-info {
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
        }

        button {
            background-color: #FF0000;
            color: #fff;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            display: block;
            margin: 0 auto;
        }

        footer {
            background-color: #000;
            color: #fff;
            text-align: center;
            padding: 20px 0;
        }

        footer a {
            color: #FF0000;
            text-decoration: none;
        }
    </style>
</head>

<body>
<?php 
    $fullname = $cardNumber = $expirationDate = $cvv = $paymentMethod = "";

    if(isset($_POST['submit'])) {
        $fullname = $_POST['fullname'];
        $cardNumber = $_POST['card-number'];
        $expirationDate = $_POST['expiration-date'];
        $cvv = $_POST['cvv'];
        $paymentMethod = $_POST['payment-method'];
        $userID = 1; // Assuming userID is 1 for demonstration purposes

        $host = "localhost";
        $user = "root";
        $password = ""; // Corrected variable name
        $database = "test";
        $connect = mysqli_connect($host, $user, $password, $database);

        if(mysqli_connect_errno()){
            die("Cannot connect to database field: " . mysqli_connect_error());
        } else {
            echo 'Database is connected';  
        }

        $sql = "CREATE TABLE IF NOT EXISTS Card (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
            fullname VARCHAR(30) NOT NULL,
            cardNumber VARCHAR(30) NOT NULL,
            expirationDate VARCHAR(255) NOT NULL,
            cvv VARCHAR(50) NOT NULL,
            paymentMethod VARCHAR(30) NOT NULL,
            userID INT NOT NULL,
            FOREIGN KEY (userID) REFERENCES usersfinal(id)
        )";

        if(mysqli_query($connect, $sql)) {
            echo "Table Highlights created successfully";
        } else {
            echo "Error creating table: " . mysqli_error($connect);  
        }

        $sql = "INSERT INTO Card (fullname, cardNumber, expirationDate, cvv, paymentMethod, userID) 
                VALUES ('$fullname', '$cardNumber', '$expirationDate', '$cvv', '$paymentMethod', '$userID')";

        if (mysqli_query($connect, $sql)) {
            echo "New records created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($connect);
        }

        header("Location: red_hawk.php");

        mysqli_close($connect);
    }
?>
    <header>
        <img src="RED HAWK.png" alt="Red Hawk Trip Planner Logo">
    </header>

    <div class="payment-container">
        <h2>Payment Information</h2>

        <form action="" method="post">
        <div class="form-group">
            <label for="fullname">Full Name (As shown on your card) : </label>
            <input type="text" id="fullname" name="fullname" required>
        </div>

        <div class="form-group">
            <label for="card-number">Card Number:</label>
            <input type="text" id="card-number" name="card-number" required>
        </div>

        <div class="form-group">
            <label for="expiration-date">Expiration Date:</label>
            <input type="text" id="expiration-date" name="expiration-date" placeholder="MM/YYYY" required>
        </div>

        <div class="form-group">
            <label for="cvv">CVV:</label>
            <input type="text" id="cvv" name="cvv" required>
        </div>

        <!-- Payment Options -->
        <div class="form-group">
            <label for="payment-method">Select Payment Method:</label>
            <select id="payment-method" name="payment-method" required>
                <option value="credit-card">Credit Card</option>
                <option value="paypal">PayPal</option>
                <option value="debit-card">Debit Card</option>
            </select>
        </div>

        <!-- Additional fields based on the selected payment method -->
        <div id="credit-card-info" class="payment-info">
            <!-- Include Credit Card-specific fields here -->
            <!-- For example, you may need billing address details -->
            <label for="billing-address">Billing Address:</label>
            <input type="text" id="billing-address" name="billing-address">
        </div>

        <div id="paypal-info" class="payment-info">
            <p>PayPal will be redirected for payment. Click 'Submit Payment' to continue.</p>
        </div>
        <input type="submit" name="submit" value="Submit and Make a Payment" class="btn-green">

</form>

    </div>

    <footer>
        <p>Contact Information: <a href="mailto:info@travelixtripplanner.com">info@travelix.com</a></p>
        <p>Follow Us: <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a></p>
        <p>&copy; 2023 Travelix Trip Planner. All rights reserved.</p>
        <p><a href="aboutUs.html">About Us</a></p>
    </footer>

    
</body>

</html>
