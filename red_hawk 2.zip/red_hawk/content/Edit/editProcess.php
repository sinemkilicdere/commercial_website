<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['tourName'])) {
    // Database connection parameters
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "test";

    // Establish a connection to the database
    $conn = mysqli_connect($host, $user, $password, $database);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $tourName = $_POST["tourName"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $ticketsLeft = $_POST["ticketsLeft"];
    $image = $_POST["image"];

      // // Query to update user information based on username
      $sql = "UPDATE Tours SET description = '$description', price = '$price', ticketsLeft = '$ticketsLeft', image = '$image' WHERE tourName = '$tourName'";
      if (mysqli_query($conn, $sql)) {
          echo "User information updated successfully.";
          header("Location: ../adminPortal.php");
      } else {
          echo "Error updating user information: " . mysqli_error($conn);
      }

    // Close the database connection
    mysqli_close($conn);
} else {
    // If the form was not submitted, redirect back to the previous page or show an error message
    echo "Invalid request.";
}
?>