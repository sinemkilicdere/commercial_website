<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['tourName'])) {
    // Database connection parameters
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "test";

   

    // Establish a connection to the database
    $conn = mysqli_connect($host, $user, $password, $database);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve the username from the form submission
    $tourName = $_POST['tourName'];

    // Query to retrieve user information based on username
    $sql = "SELECT * FROM Tours WHERE tourName = '$tourName'";
    $result = mysqli_query($conn, $sql);



    // Close the database connection
    mysqli_close($conn);

    // Check if the query executed successfully and if any row is returned
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result); // Fetch user data

        // Now you can display an edit form with the existing user information
        ?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Edit User</title>
            <link rel="stylesheet" href="editUserStyles.css">
            <link rel="stylesheet" href="styles.css">
        </head>
        <body>
            <h2>Edit User</h2>
            <form action="editProcess.php" method="post">
                <label for="name">tourName:</label>
                <input type="text" id="tourName" name="tourName" value="<?php echo $row['tourName']; ?>"><br><br>
                <label for="password">tourDescription:</label>
                <input type="text" id="description" name="description" value="<?php echo $row['description']; ?>"><br><br>
                <label for="email">price:</label>
                <input type="text" id="price" name="price" value="<?php echo $row['price']; ?>"><br><br>
                <label for="name">ticketsLeft:</label>
                <input type="text" id="ticketsLeft" name="ticketsLeft" value="<?php echo $row['ticketsLeft']; ?>"><br><br>
                <label for="name">image:</label>
                <input type="text" id="image" name="image" value="<?php echo $row['image']; ?>"><br><br>
                <input type="submit" value="Update">
            </form>
        </body>
        </html>

        <?php
    } else {
        echo "User not found.";
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // If the form was not submitted, redirect back to the previous page or show an error message
    echo "Invalid request.";
}
?>