<!DOCTYPE html>
<html lang="en">
<!-- 
-- INSERT INTO Tours (tourName, description, price, ticketsLeft, userID)
-- VALUES ('Central Park Tour', 'A guided tour through the most iconic Park of New York City.', '40', '50', 1); -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book NYC Highlights Tour - Red Hawk Trip Planner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        header {
            background-color: #000;
            color: #fff;
            padding: 0px 0;
            text-align: center;
        }

        .tour-details {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            text-align: left;
            padding: 50px 20px;
            box-sizing: border-box;
        }

        .tour-details h1 {
            color: #FF0000;
        }

        .tour-details img {
            width: 100%;
            max-width: 400px;
            height: auto;
            margin-bottom: 20px;
        }

        .tour-highlights {
            width: 45%;
            margin-left: 10em;
        }

        .tour-highlights h2 {
            color: #000;
        }

        .tour-highlights ul {
            list-style: none;
            padding: 0;
        }

        .tour-highlights li {
            margin-bottom: 10px;
        }

        .booking-form {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            box-sizing: border-box;
        }

        .booking-form label {
            display: block;
            margin-bottom: 10px;
            color: #000;
        }

        .booking-form input,
        .booking-form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .booking-form button {
            background-color: #FF0000;
            color: #fff;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            display: block;
            margin: 0 auto;
        }

        footer {
            background-color: #000;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }

        footer a {
            color: #FF0000;
            text-decoration: none;
        }

        .error {
            background-color: red;
        }
    </style>
</head>

<body>
    
<?php 
    $people = $pickup = $insurance = $day = $timeframe = $fullname = $cardNumber  = $expirationDate = $cvv = $paymentMethod = "";

    $ticketErr = "";

    if(isset($_POST['submit'])) {
        session_start();

        if(isset($_SESSION["UserID"]) && isset($_SESSION['tour_id'])) {
            $userID = $_SESSION['UserID'];
            $tourID = $_SESSION['tour_id'];
    
            $people = $_POST['people'];
            $pickup = $_POST['pickup'];
            $insurance = $_POST['insurance'];
            $day = $_POST['day'];
            $timeframe = $_POST['timeframe'];
    
            $fullname = $_POST['fullname'];
            $cardNumber = $_POST['card-number'];
            $expirationDate = $_POST['expiration-date'];
            $cvv = $_POST['cvv'];
            $paymentMethod = $_POST['payment-method'];

            $host = "localhost";
            $user = "root";
            $password = ""; // Corrected variable name
            $database = "test";
            $connect = mysqli_connect($host, $user, $password, $database);
    
            if(mysqli_connect_errno()){
                die("Cannot connect to database field: " . mysqli_connect_error());
            } else {
                echo 'Database is connected';  
            }

            $sql = "SELECT ticketsLeft FROM Tours WHERE id = $tourID";

            // Execute the query
            $result = mysqli_query($connect, $sql);

            // Check if any rows were returned
            if (mysqli_num_rows($result) > 0) {
                // Output data of each row
                while($row = mysqli_fetch_assoc($result)) {
                    $ticketsLeft = $row['ticketsLeft'];
                }
            } else {
                echo "0 results";
            }

            // Calculate the updated number of tickets left
            $updated_tickets_left = $ticketsLeft - $people;

            $updated_tickets_left = $ticketsLeft - $people;
            if ($updated_tickets_left < 0) {
                $ticketErr = "Error: Not enough tickets left.";
            } else {
                
            
                    $sql = "CREATE TABLE IF NOT EXISTS Trips (
                        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
                        people VARCHAR(30) NOT NULL,
                        pickup VARCHAR(255) NOT NULL,
                        insurance VARCHAR(50) NOT NULL,
                        day VARCHAR(30) NOT NULL,
                        timeframe VARCHAR(255) NOT NULL,
                        userID INT NOT NULL,
                        FOREIGN KEY (userID) REFERENCES TicketUsers(id)
                    )";
            
                    if(mysqli_query($connect, $sql)) {
                        echo "Table Trips created successfully";
                    } else {
                        echo "Error creating table: " . mysqli_error($connect);  
                    }
            
                    $sql1 = "INSERT INTO Trips (people, pickup, insurance, day, timeframe,  userID) 
                    VALUES ('$people', '$pickup', '$insurance', '$day', '$timeframe', $userID)";
            
                    if (mysqli_query($connect, $sql1)) {
                        echo "New records created successfully";
                    } else {
                        echo "Error: " . $sql1 . "<br>" . mysqli_error($connect);
                    }
            
                    // update the Tours Table everytime customers buy the tickets
                    $sql_update_tickets = "UPDATE Tours SET ticketsLeft = ticketsLeft - $people WHERE id = $tourID";
            
                    // Execute the update query
                    if (mysqli_query($connect, $sql_update_tickets)) {
                        echo "Tickets left updated successfully";
                    } else {
                        echo "Error updating tickets left: " . mysqli_error($connect);
                    }
            
                    $sql = "CREATE TABLE IF NOT EXISTS Card (
                                id INT NOT NULL AUTO_INCREMENT, 
                                fullname VARCHAR(30) NOT NULL,
                                cardNumber VARCHAR(30) NOT NULL PRIMARY KEY,
                                expirationDate VARCHAR(255) NOT NULL,
                                cvv VARCHAR(50) NOT NULL,
                                paymentMethod VARCHAR(30) NOT NULL,
                                userID INT NOT NULL,
                                FOREIGN KEY (userID) REFERENCES TicketUsers(id)
                    )";
            
                    if(mysqli_query($connect, $sql)) {
                        echo "Table Card created successfully";
                    } else {
                        echo "Error creating table: " . mysqli_error($connect);  
                    }
            
                    
                    $sql = "INSERT INTO Card (fullname, cardNumber, expirationDate, cvv, paymentMethod,  userID) 
                            VALUES ('$fullname', '$cardNumber', '$expirationDate', '$cvv', '$paymentMethod', '$userID')";
            
                    if (mysqli_query($connect, $sql)) {
                        echo "New records created successfully";
                    } else {
                        echo "Error: " . $sql . "<br>" . mysqli_error($connect);
                    }
            
            
                    $sql = "CREATE TABLE IF NOT EXISTS UserTour (
                                id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                                tourID INT,
                                userID INT,
                                FOREIGN KEY (tourID) REFERENCES Tours(id),
                                FOREIGN KEY (userID) REFERENCES TicketUsers(id)
                    )";
            
                    if(mysqli_query($connect, $sql)) {
                        echo "Table Tours created successfully";
                    } else {
                        echo "Error creating table: " . mysqli_error($connect);  
                    }
            
                    $sql = "INSERT INTO UserTour (tourID, userID) 
                            VALUES ('$tourID', '$userID')";
            
                    if (mysqli_query($connect, $sql)) {
                        echo "New records created successfully";
                    } else {
                        echo "Error: " . $sql . "<br>" . mysqli_error($connect);
                    }
            
            
                    header("Location: thankyou.php");
            
                    mysqli_close($connect);
            }
    
      
        }
        }

      
?>

    <header>
        <img src="../assets/RED HAWK.png" alt="Red Hawk Trip Planner Logo">
    </header>

    <?php

session_start();
echo "Username: " .$_SESSION['Name'];
echo "<br/>";
echo "Tour ID: " . $_SESSION['tour_id'];
echo "<br/>";
echo "UserID: " . $_SESSION['UserID']

?>

    <div class="tour-details">
        <div class="tour-highlights">
            <h2>Time Frames</h2>
            <ul>
                <li>Morning: 10:00 AM - 1:00 PM</li>
                <li>Afternoon: 2:00 PM - 5:00 PM</li>
                <li>Evening: 6:00 PM - 9:00 PM</li>
            </ul>

            <h2>Highlights</h2>
            <ul>
                <li>Morning Tour (10:00 AM - 1:00 PM):</li>
                <ul>
                    <li>Times Square: The Crossroads of the World</li>
                    <li>Central Park: Nature in the Heart of the City</li>
                </ul>
                <li>Afternoon Tour (2:00 PM - 5:00 PM):</li>
                <ul>
                    <li>Empire State Building: Iconic Skyscraper Views</li>
                    <li>Statue of Liberty: Symbol of Freedom</li>
                </ul>
                <li>Evening Tour (6:00 PM - 9:00 PM):</li>
                <ul>
                    <li>Brooklyn Bridge: Connecting Manhattan and Brooklyn</li>
                    <li>$75 per person and all entrance fees are included</li>

                    <!-- Add more highlights as needed -->
                </ul>
            </ul>
        </div>

        <div class="booking-form">
            <a href="./nyc_trip.html">Back</a>
            <h2>Submit and Make a Payment</h2>
            <form action="" method="post">
                <span class="error"> <?php echo $ticketErr ?> </span>
                <br/>
                <label for="people">Number of People:</label>
                <input type="number" id="people" name="people" required>

                <label for="pickup">Pick-up Location:</label>
                <select id="pickup" name="pickup" required>
                    <option value="times_square">Times Square</option>
                    <option value="central_park">Central Park</option>
                    <option value="empire_state">Empire State Building</option>
                </select>

                <label for="insurance">Insurance:</label>
                <select id="insurance" name="insurance" required>
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                </select>

                <label for="day">Preferred Day (Select from Calendar):</label>
                <input type="date" id="day" name="day" required>

                <label for="timeframe">Preferred Time Frame:</label>
                <select id="timeframe" name="timeframe" required>
                    <option value="morning">Morning (10:00 AM - 1:00 PM)</option>
                    <option value="afternoon">Afternoon (2:00 PM - 5:00 PM)</option>
                    <option value="evening">Evening (6:00 PM - 9:00 PM)</option>
                </select>

                <div class="form-group">
                    <label for="fullname">Full Name (As shown on your card) : </label>
                    <input type="text" id="fullname" name="fullname" required>
                </div>

                <div class="form-group">
                    <label for="card-number">Card Number:</label>
                    <input type="text" id="card-number" name="card-number" required>
                </div>

                <div class="form-group">
                    <label for="expiration-date">Expiration Date:</label>
                    <input type="text" id="expiration-date" name="expiration-date" placeholder="MM/YYYY" required>
                </div>

                <div class="form-group">
                    <label for="cvv">CVV:</label>
                    <input type="text" id="cvv" name="cvv" required>
                </div>

                <!-- Payment Options -->
                <div class="form-group">
                    <label for="payment-method">Select Payment Method:</label>
                    <select id="payment-method" name="payment-method" required>
                        <option value="credit-card">Credit Card</option>
                        <option value="paypal">PayPal</option>
                        <option value="debit-card">Debit Card</option>
                    </select>
                </div>

                <div id="paypal-info" class="payment-info">
                    <p>PayPal will be redirected for payment. Click 'Submit Payment' to continue.</p>
                </div>


                <p>Note: The remaining payment will be charged at the pick-up location.Minimum deposit amount $50 per person.</p>

                <input type="submit" name="submit" value="Submit and Make a Payment" class="btn-green">


            </form>
        </div>
    </div>

    <footer>
        <p>Contact Information: <a href="mailto:info@travelixtripplanner.com">info@travelix.com</a></p>
        <p>Follow Us: <a href="#">Facebook</a> | <a href="#">Twitter</a> | <a href="#">Instagram</a></p>
        <p>&copy; 2023 Travelix Trip Planner. All rights reserved.</p>
        <p><a href="aboutUs.html">About Us</a></p>
    </footer>




</body>

</html>
